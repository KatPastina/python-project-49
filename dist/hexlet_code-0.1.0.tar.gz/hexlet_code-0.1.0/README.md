### Hexlet tests and linter status:
[![Actions Status](https://github.com/KatPastina/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/KatPastina/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/4b00ad81bb0321883c52/maintainability)](https://codeclimate.com/github/KatPastina/python-project-49/maintainability)
